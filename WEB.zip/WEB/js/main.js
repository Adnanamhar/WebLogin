console.log("Hello Adnan");
document.write("Hello Adnan");
window.alert("Ganteng Banget");